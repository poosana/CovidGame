package coma.game.utils;

public class Ticker {
    final private float inputtedDelay;
    private float currentDelay;

    public Ticker(float delay) {
        this.inputtedDelay = delay;
    }

    public void update(float deltaTime) {
        this.currentDelay -= deltaTime;
    }

    public boolean isTicked() {
        if (this.currentDelay < 0) {
            this.currentDelay = this.inputtedDelay;

            return true;
        }

        return false;
    }
}
