package coma.game.components;

import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import coma.game.controllers.UIController;

final public class TextBox extends Renderable {

    public float x;
    public float y;
    public float translateX;
    public float translateY;

    private float r = 1;
    private float g = 1;
    private float b = 1;
    private float a = 1;

    private final BitmapFont bitmapFont;
    public String textContent = "";

    public TextBox(final BitmapFont bitmapFont) {
        this.bitmapFont = bitmapFont.getCache().getFont();

        UIController.addComponents(this);
    }

    public void setColor(final float r, final float g, final float b) {
        this.r = r;
        this.g = g;
        this.b = b;

        this.bitmapFont.setColor(this.r, this.g, this.b, this.a);
    }

    public void setOpacity(final float value) {
        this.a = value;

        this.bitmapFont.setColor(this.r, this.g, this.b, this.a);
    }

    public void setPosition(final float x, final float y) {
        this.x = x;
        this.y = y;
    }

    public void render(final SpriteBatch b) {
        if (this.isVisible) {
            this.bitmapFont.draw(b, this.textContent, this.x + translateX, this.y + translateY);
        }
    }
}
