package coma.game.components;

import coma.game.controllers.UIController;

import java.util.ArrayList;
import java.util.Arrays;

final public class UIBoxModule {

    private Renderable[] moduleList;

    private boolean isVisible = true;

    public UIBoxModule(final Renderable[] moduleList) {
        this.moduleList = moduleList;
    }

    public void append(final Renderable ...moduleList) {
        this.moduleList = UIBoxModule.concatWithArrayCopy(this.moduleList, moduleList);
    }

    public void setVisibility(final boolean value) {
        for (final Renderable canvas : this.moduleList) {
            canvas.isVisible = value;
        }

        this.isVisible = value;
    }

    public boolean isVisible() {
        return this.isVisible;
    }

    static <T> T[] concatWithArrayCopy(T[] array1, T[] array2) {
        T[] result = Arrays.copyOf(array1, array1.length + array2.length);
        System.arraycopy(array2, 0, result, array1.length, array2.length);
        return result;
    }
}
