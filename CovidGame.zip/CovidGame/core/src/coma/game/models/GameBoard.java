package coma.game.models;

import coma.game.Resources;
import coma.game.components.Canvas;
import coma.game.models.contents.Antibody;
import coma.game.models.contents.Unit;
import coma.game.models.contents.Virus;

import java.util.concurrent.ThreadLocalRandom;

public class GameBoard {
    private Unit[][] occupiedTiles = new Unit[14][14];

    public GameBoard() {

    }

    public void deploy(Unit unit, int row, int col) {
        this.occupiedTiles[row][col] = unit;

        unit.setTile(row, col);
    }

    public Virus spawnSignleGermRandomly(int level) {
        // get unique position
        int randRow = this.rand();
        int randCol = this.rand();

        System.out.println(randRow + " " + randCol);

        while (!this.isTileAvailable(randRow, randCol)) {
            randRow = this.rand();
            randCol = this.rand();

            System.out.println("rand: " + randRow + " " + randCol);
        }

        Virus v = null;

        if (level == 1) {
            v = Virus.createUnit1();
        }
        else if (level == 2) {
            v = Virus.createUnit2();
        }
        else if (level == 3) {
            v = Virus.createUnit3();
        }
        else {
            throw new RuntimeException("virus index out of bound");
        }

        v.setTile(randRow, randCol);

        this.occupiedTiles[randRow][randCol] = v;

        return v;
    }

    private int rand() {
        return ThreadLocalRandom.current().nextInt(0, 14);
    }

    public void enableToggleAvailableTiles() {
        for (int i = 0; i < Resources.tiles.length; i++) {
            for (int j = 0; j < Resources.tiles[i].length; j++) {
                Canvas tile = Resources.tiles[i][j];

                if (!this.isTileAvailable(i, j)) {
                    tile.setActive(false);
                }
            }
        }
    }

    public boolean hasAntibodyOnBoard() {
        for (int i = 0; i < Resources.tiles.length; i++) {
            for (int j = 0; j < Resources.tiles[i].length; j++) {
                if (this.occupiedTiles[i][j] instanceof Antibody) {
                    return true;
                }
            }
        }

        return false;
    }

    public boolean hasVirusOnBoard() {
        for (int i = 0; i < Resources.tiles.length; i++) {
            for (int j = 0; j < Resources.tiles[i].length; j++) {
                if (this.occupiedTiles[i][j] instanceof Virus) {
                    return true;
                }
            }
        }

        return false;
    }

    public int[] getPositionOf(Unit unit) {
        for (int i = 0; i < Resources.tiles.length; i++) {
            for (int j = 0; j < Resources.tiles[i].length; j++) {
                if (unit == this.occupiedTiles[i][j]) {
                    return new int[] { i, j };
                }
            }
        }

        return null;
    }

    public boolean hasAntibodyNearby(int row, int col) {
        final boolean nw = row > 0 && col > 0
                && this.occupiedTiles[row - 1][col - 1] instanceof Antibody;
        final boolean n = row > 0
                && this.occupiedTiles[row - 1][col] instanceof Antibody;
        final boolean ne = row > 0 && col < 13
                && this.occupiedTiles[row - 1][col + 1] instanceof Antibody;
        final boolean e = col < 13 &&
                this.occupiedTiles[row][col + 1] instanceof Antibody;
        final boolean se = row < 13 && col < 13 &&
                this.occupiedTiles[row + 1][col + 1] instanceof Antibody;
        final boolean s = row < 13 &&
                this.occupiedTiles[row + 1][col] instanceof Antibody;
        final boolean sw = row < 13 && col > 0 &&
                this.occupiedTiles[row + 1][col - 1] instanceof Antibody;
        final boolean w = col > 0 &&
                this.occupiedTiles[row][col - 1] instanceof Antibody;

        return nw || n || ne || e || se || s || sw || w;
    }

    public void destroy() {
        for (Unit[] row : this.occupiedTiles) {
            for (Unit unit : row) {
                if (unit != null) {
                    unit.destroy();
                }
            }
        }

        this.occupiedTiles = null;
    }

    public void reset() {
        for (int i = 0; i < Resources.tiles.length; i++) {
            for (int j = 0; j < Resources.tiles[i].length; j++) {
                Canvas tile = Resources.tiles[i][j];

                tile.setActive(true);
            }
        }
    }

    public boolean isTileAvailable(int row, int col) {
        return this.occupiedTiles[row][col] == null;
    }
}
