package coma.game.models;

import coma.game.models.contents.*;

import java.util.ArrayList;

public class Player {
    // properties
    private final ArrayList<Unit> units = new ArrayList<>();

    private int cash = 50;

    public Player() {

    }

    public void addUnit(Antibody a) {
        this.units.add(a);
    }

    public void remove(Antibody a) {
        this.units.remove(a);
    }

    private void updateCashBound() {
        if (this.cash <= 0) this.cash = 0;
        if (this.cash >= 300) this.cash = 300;
    }

    public int getCash() {
        return this.cash;
    }

    public void addCash(int amount) {
        this.cash += amount;

        this.updateCashBound();
    }

    public void deduceCash(int amount) {
        this.cash -= amount;

        this.updateCashBound();
    }

    public boolean checkCashSufficiency(int price) {
        return this.cash >= price;
    }
}