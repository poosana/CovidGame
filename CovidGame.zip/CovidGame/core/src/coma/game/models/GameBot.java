package coma.game.models;

import org.w3c.dom.ranges.RangeException;

final public class GameBot extends Player {
    public byte difficulty = 1;
    private boolean isWaking = false;
    private byte decisionDelay = 120;
    private byte state = 1;

    public static final byte DECISION_DELAY = 120;

    public static short getUltimateDelay(final byte difficulty) {
        switch (difficulty) {
            case 1: return 6000;
            case 2: return 5000;
            case 3: return 4000;
            default: throw new RangeException((short) 0, "Wrong parameter input.");
        }
    }
}
