package coma.game.controllers;

import coma.game.models.GameBoard;
import coma.game.models.GameBot;
import coma.game.models.Player;
import coma.game.models.contents.Unit;

final public class GameState {

    public boolean isGameStarted = false;
    public int selectedDeployUnit = 0;
    public Player player = null;
    public GameBot gameBot = null;
    public GameBoard gameBoard = null;
    public int wave = 0;
    public boolean isFighting = false;

    private int waveFormulaList[][] = {
            { 1, 1, 1, 1, 1, 1, 1 },
            { 1, 1, 1, 2, 2, 2, 3 },
            { 1, 2, 2, 2, 3, 3, 3 }
    };

    public void start() {
        this.isGameStarted = true;

        this.player = new Player();
        this.gameBot = new GameBot();
        this.gameBoard = new GameBoard();
    }

    public void end() {

    }

    public void nextTurn() {
        if (this.wave >= 3) {
            return;
        }

        this.wave += 1;

        for (int level : this.waveFormulaList[this.wave - 1]) {
            this.gameBoard.spawnSignleGermRandomly(level);
        }

        this.isFighting = true;
    }

    public void setGameOver(final boolean isWon) {
        /* GameStatus.isGameStarted = false;

        UIController.getBoxModule("in-game-menu").setVisibility(false);
        UIController.getBoxModule("game-over-menu").setVisibility(true);

        if (isWon) Resources.winSound.play();
        else Resources.loseSound.play();

        if (MainGame.gameSpeed != 1) {
            Resources.speedBtn.click();
        }

        Resources.victoryBanner.isVisible = isWon;
        Resources.defeatBanner.isVisible = !isWon; */
    }
}
